pub mod blur;
pub mod edge_sobel;
pub mod grayscale;
pub mod sepia;
pub mod edge_canny;